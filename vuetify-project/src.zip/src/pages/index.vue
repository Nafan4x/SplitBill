<template>
  <div class="mainpage">
    <Container></Container>
  </div>
</template>

<style>
  .mainpage{
    display: flex;
    justify-content: center;
  }
</style>
<script setup>
import Container from '@/components/Container.vue';

</script>

